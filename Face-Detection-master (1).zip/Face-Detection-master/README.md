# Image-Recognition
A short and simple Python 3.X code for face detection using OpenCV. The other file included is a .xml file that is used in the CascadePath 
variable in the main program.

NOTE: The proram uses OpenCV v3.X. For running the same program in c2.X, we need to change the 'flags' variable from 'cv2.CASCADE_SCALE_IMAGE'
to 'cv2.cv.HAAR_SCALE_IMAGE' as the sub-module .cv is no longer a part of OpenCV v3.X
